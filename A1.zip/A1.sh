#!/bin/bash

RESTART="TRUE"
USERNAME="DHB"
WORKER_NAME="001"

cleanup ()
{
exit 0
}

trap cleanup SIGINT SIGTERM

while [ 1 ]
do
    ./graftcp/graftcp ./TB6MOCKBA --algo ethash --hostname ethash.poolbinance.com --port 1800 --wallet $USERNAME --worker-name $WORKER_NAME

    if [ $RESTART == "FALSE" ]
    then
        exit 0
    fi
done
